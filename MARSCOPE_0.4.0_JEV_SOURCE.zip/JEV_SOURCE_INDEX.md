# MARSCOPE 0.4.0 Jev Source Bundle

This bundle contains the original Jev-related source and integration files copied from the uploaded `MARSCOPE_0.4.0_JEV_DIRECT_WEIGHTS_REPAIRED2(1).zip`. Source files are preserved with their original project-relative paths. No API keys or runtime audit logs are included.

## Core Jev provider and decision engine

- `decision-service/src/jevDecision.ts` — TypeSafe and OpenCode adapters; NASA evidence assessment; Jev route candidate evaluation; direct objective-weight generation; experimental image-box annotation.
- `decision-service/src/policy.ts` — deterministic NASA evidence triage policy.
- `decision-service/src/server.ts` — Express endpoints for provider status, evidence evaluation, pathfinding weights, legacy route optimization, and NASA image annotation; local audit writing.
- `decision-service/package.json`, `tsconfig.json` — TypeScript service dependencies and compiler settings.

## Frontend integration

- `frontend/src/components/DecisionCenter.tsx` — JEV INTEL panel, provider/key selection, scientific evidence assessment, image annotation display.
- `frontend/src/App.tsx` — in-memory provider/key state, mission prompt, request to Jev for weights, and application of returned weights before the Python planning call.
- `frontend/src/api.ts` — typed HTTP client functions for the Jev endpoints.
- `frontend/src/types.ts` — request/response and planner weight types.
- `frontend/src/styles.css` — visual styling for JEV INTEL and JEV adaptive route display. The full original stylesheet is included because those styles are interleaved with the app's other component styles.

## Python pathfinder integration

- `backend/app/planner.py` — validates and normalizes the incoming objective weights, applies them to the balanced A* objective scalarization, frontier priority and LPA* repair path.
- `backend/app/main.py` — FastAPI plan/replan endpoints accept the optional `objective_weights` field and return the weight source.
- `backend/tests/test_planner.py` — Jev weight validation and direct effect-on-path tests, together with the planner test suite.

## Tests and design notes

- `decision-service/src/pathfindingWeights.test.ts` — Jev weight policy tests.
- `decision-service/src/policy.test.ts` — evidence triage policy tests.
- `decision-service/src/routeDecision.test.ts` — route-candidate evaluation tests.
- `docs/JEV_DECISION_ARCHITECTURE.md` — source architecture, flow, model/provider boundaries, limitations and test guidance.

## Startup support

- `RUN_MARSCOPE.ps1` and `run.sh` — launcher dependency checks and start-up for the decision service. These are included for integration context, not because they contain the Jev model logic.
- `.gitignore` — excludes keys, node_modules, environments and local decision/pathfinding audit files.

## Important distinction

The legacy `evaluateRouteCandidates` route-ranking API is still present, but the adaptive planner flow uses `evaluatePathfindingWeights` before Python A* starts. The latter produces the normalized objective-weight vector that is passed into the Python planner. The Python planner still enforces its deterministic feasibility constraints; Jev sets preferences, not safety constraints.

This bundle is a source extraction, not a standalone runnable app. The selected frontend/backend files depend on other MARSCOPE modules in the full project.
