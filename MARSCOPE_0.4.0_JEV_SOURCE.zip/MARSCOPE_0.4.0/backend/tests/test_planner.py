import pytest
from app.planner import MissionConstraints, MultiObjectiveAStar, build_route_set, route_metrics
from app.terrain import generate_terrain


def test_route_stays_inside_grid_and_avoids_hard_blocked_cells():
    terrain = generate_terrain(seed=11)
    constraints = MissionConstraints(max_slope_deg=35, max_temperature_c=0)
    result = MultiObjectiveAStar(terrain, constraints, "balanced").search((3, 3), (58, 58))
    assert result["path"][0] == (3, 3)
    assert result["path"][-1] == (58, 58)
    for x, y in result["path"]:
        assert not terrain.is_blocked(x, y, constraints.max_slope_deg, constraints.max_temperature_c)


def test_three_policy_routes_are_returned_with_comparable_metrics():
    terrain = generate_terrain(seed=12)
    routes = build_route_set(terrain, (3, 3), (58, 58), MissionConstraints(max_slope_deg=35, max_temperature_c=0))
    assert {r["profile"] for r in routes} == {"conservative", "balanced", "science_first"}
    for route in routes:
        assert route["metrics"]["distance_m"] > 0
        assert 0 <= route["metrics"]["uncertainty_pct"] <= 100
        assert "return_feasible" in route["metrics"]


def test_resource_limited_mission_can_be_rejected():
    terrain = generate_terrain(seed=12)
    c = MissionConstraints(eva_limit_minutes=10, energy_budget_wh=10, max_slope_deg=35, max_temperature_c=0)
    try:
        MultiObjectiveAStar(terrain, c, "balanced").search((3, 3), (58, 58))
    except ValueError as exc:
        assert "No route" in str(exc)
    else:
        raise AssertionError("Expected a route rejection under restrictive resources")


def test_objective_weight_multipliers_are_normalized_and_configurable():
    from app.planner import MissionConstraints, MultiObjectiveAStar
    from app.terrain import generate_terrain

    terrain = generate_terrain(width=24, height=24)
    constraints = MissionConstraints.from_dict({
        "objective_weight_multipliers": {
            "science_opportunity_cost": 2.5,
            "terrain_risk": 1.8,
            "uncertainty": 1.5,
        }
    })
    model = MultiObjectiveAStar(terrain, constraints, "balanced")
    assert sum(model.weights.values()) == pytest.approx(1.0)
    assert model.weights["science_opportunity_cost"] > 0.048
    with pytest.raises(ValueError, match="between 0 and 5"):
        MissionConstraints.from_dict({"objective_weight_multipliers": {"distance": 6}})
    with pytest.raises(ValueError, match="At least one objective"):
        no_objectives = MissionConstraints.from_dict({"objective_weight_multipliers": {key: 0 for key in model.weights}})
        MultiObjectiveAStar(terrain, no_objectives, "balanced")


def test_unavailable_science_environment_and_radiation_are_n_a_not_fake_zeroes():
    from app.planner import MissionConstraints, MultiObjectiveAStar, route_metrics
    from app.terrain import generate_terrain

    terrain = generate_terrain(seed=42)
    terrain.available_layers.discard("science")
    terrain.available_layers.discard("atmosphere")
    terrain.available_layers.discard("radiation")
    constraints = MissionConstraints(max_slope_deg=35, max_temperature_c=0)
    search = MultiObjectiveAStar(terrain, constraints, "balanced").search((3, 3), (58, 58))
    metrics = route_metrics(terrain, search["path"], constraints)
    assert metrics["scientific_value_pct"] is None
    assert metrics["environment_risk_pct"] is None
    assert metrics["radiation_index_pct"] is None
    weights = MultiObjectiveAStar(terrain, constraints, "balanced").weights
    assert weights["science_opportunity_cost"] == 0
    assert weights["environment_risk"] == 0
    assert weights["radiation"] == 0


def test_jev_objective_weights_are_used_directly_inside_balanced_a_star_and_lpa():
    from app.lpa import LPAStar

    terrain = generate_terrain(width=24, height=24, seed=17)
    constraints = MissionConstraints.from_dict({
        "max_slope_deg": 35,
        "max_temperature_c": 0,
        "objective_weights": {
            "distance": 0.05,
            "time": 0.05,
            "energy": 0.05,
            "terrain_risk": 0.55,
            "environment_risk": 0.05,
            "radiation": 0.05,
            "uncertainty": 0.10,
            "science_opportunity_cost": 0.05,
            "oxygen": 0.05,
        },
    })

    adaptive = MultiObjectiveAStar(terrain, constraints, "balanced")
    baseline = MultiObjectiveAStar(terrain, MissionConstraints(max_slope_deg=35, max_temperature_c=0), "balanced")
    incremental = LPAStar(terrain, (2, 2), (21, 21), constraints)

    assert adaptive.weight_source == "jev_prompt"
    assert adaptive.weights["terrain_risk"] > baseline.weights["terrain_risk"]
    assert sum(adaptive.weights.values()) == pytest.approx(1.0)
    assert incremental.weights == adaptive.weights


def test_jev_weights_only_replace_balanced_route_and_keep_profile_baselines():
    terrain = generate_terrain(width=24, height=24, seed=18)
    constraints = MissionConstraints.from_dict({
        "max_slope_deg": 35,
        "max_temperature_c": 0,
        "objective_weights": {
            "distance": 0.05,
            "time": 0.05,
            "energy": 0.05,
            "terrain_risk": 0.55,
            "environment_risk": 0.05,
            "radiation": 0.05,
            "uncertainty": 0.10,
            "science_opportunity_cost": 0.05,
            "oxygen": 0.05,
        },
    })
    routes = build_route_set(terrain, (2, 2), (21, 21), constraints)
    by_profile = {route["profile"]: route for route in routes}

    assert by_profile["balanced"]["weight_source"] == "jev_prompt"
    assert by_profile["balanced"]["name"] == "JEV-ADAPTIVE"
    assert by_profile["conservative"]["weight_source"] == "static_profile"
    assert by_profile["science_first"]["weight_source"] == "static_profile"
    assert by_profile["balanced"]["weights"]["terrain_risk"] > by_profile["conservative"]["weights"]["terrain_risk"]


def test_invalid_jev_objective_weight_vectors_are_rejected():
    with pytest.raises(ValueError, match="between 0 and 1"):
        MissionConstraints.from_dict({"objective_weights": {"distance": 1.5}})
    with pytest.raises(ValueError, match="greater than zero"):
        MissionConstraints.from_dict({"objective_weights": {"distance": 0.0, "time": 0.0}})
    with pytest.raises(ValueError, match="Unknown planner objectives"):
        MissionConstraints.from_dict({"objective_weights": {"unlisted": 0.5}})


def test_jev_weight_preferences_change_the_actual_ast_route_not_only_its_display_score():
    terrain = generate_terrain(width=32, height=32, seed=1)
    distance_weights = {key: 0.00625 for key in (
        "distance", "time", "energy", "terrain_risk", "environment_risk",
        "radiation", "uncertainty", "science_opportunity_cost", "oxygen",
    )}
    distance_weights["distance"] = 0.95
    risk_weights = dict(distance_weights)
    risk_weights["distance"] = 0.00625
    risk_weights["terrain_risk"] = 0.95

    distance_constraints = MissionConstraints.from_dict({
        "max_slope_deg": 35, "max_temperature_c": 0, "objective_weights": distance_weights,
    })
    risk_constraints = MissionConstraints.from_dict({
        "max_slope_deg": 35, "max_temperature_c": 0, "objective_weights": risk_weights,
    })
    distance_model = MultiObjectiveAStar(terrain, distance_constraints, "balanced")
    risk_model = MultiObjectiveAStar(terrain, risk_constraints, "balanced")
    distance_result = distance_model.search((2, 2), (29, 29))
    risk_result = risk_model.search((2, 2), (29, 29))

    assert distance_result["path"] != risk_result["path"]
    assert len(distance_result["path"]) < len(risk_result["path"])
    assert distance_result["objective_vector"]["terrain_risk"] > risk_result["objective_vector"]["terrain_risk"]
