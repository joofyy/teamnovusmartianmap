# MARSCOPE Jev Decision Architecture (0.4.0)

## Responsibility split

Jev supplies structured mission-preference judgments. MARSCOPE's TypeScript decision service converts those judgments into a versioned objective-weight vector. Python owns terrain, geospatial and route calculations and consumes that vector directly inside weighted multi-objective A* and LPA*. Jev can strongly influence route preference, but it cannot create coordinates, change terrain values or waive deterministic hard constraints.

```text
User mission prompt + operational context + available terrain layers
          │
          ▼
TypeScript decision-service
  ├── Provider: TypeSafe SDK or OpenCode Console HTTP
  ├── Choice: select a strategic focus
  ├── Score: rate each available objective's importance (0–3)
  ├── Noul: estimate each objective's mission relevance
  └── normalize: 90% Jev judgments + 10% strategy prior
          │
          ▼
Validated normalized objective-weight vector
          │
          ▼
Python planner
  ├── weighted multi-objective A* edge-cost scalarization
  ├── A* queue priority and bounded Pareto-label pruning
  ├── deterministic slope / temperature / obstacle checks
  ├── time / energy / oxygen / return-reserve feasibility checks
  └── LPA* incremental repair with the same weight vector
          │
          ▼
JEV-ADAPTIVE balanced route + static comparison baselines
          │
          ▼
React map + actual weight breakdown + decision provenance
```

## Temporary credential lifecycle

1. The user pastes the key into the password field in the JEV INTEL panel (`DecisionCenter.tsx`).
2. React holds it in the parent `App.tsx` component state only, so it remains available when switching from JEV INTEL back to the route planner. No localStorage, sessionStorage, cookie, URL, or `.env` write is performed.
3. The browser sends the key in the JSON body to the loopback-only Node service.
4. The selected provider determines the server-side adapter: TypeSafe uses `TypeSafeClient` with the explicit `apiKey` option; OpenCode uses a bearer-authenticated `fetch` to `https://opencode.ai/inference/systemone/v1/systemone` and requests `jev-1.13-free`.
5. The authenticated request is sent over HTTPS. The key is not copied to `process.env`.
6. The audit writer records objective, hypothesis, source IDs and decision labels only. It never receives or stores the key.
7. Changing providers, pressing Forget, or refreshing clears the UI key state. Switching between the planner and JEV INTEL tabs does not clear it because both features share the same in-memory parent state.

The Node server listens on `127.0.0.1` by default. Do not expose it to a LAN or public interface without adding authentication, TLS and request-origin protections. The local request body exists in browser/server memory while processing; MARSCOPE does not promise erasure from operating-system memory or third-party browser tooling.

## Evidence questions

Each record is evaluated separately using four typed questions:

- `Choice`: relation to a working hypothesis.
- `Score`: objective/hypothesis relevance on an ordered 0–3 rubric.
- `Noul`: whether the supplied record itself contains observation-level support.
- `Score`: potential novelty against the objective on an ordered 0–3 rubric.

The prompt directs Jev to use only the supplied record, distinguish source description from measurement, and avoid inferring coordinates, mineral identifications or unprovided measurements.

## Decision policy

TypeSafe evidence assessments use Jev model `jev-1.14.0`; OpenCode requests its listed limited-time free model `jev-1.13-free`. OpenCode model availability may change. The image Box experiment remains TypeSafe-only and uses `jev-preview`. `policy.ts` is versioned as `jev-evidence-triage-0.4.0`. Its current thresholds are provisional engineering thresholds for triage, not empirically calibrated cutoffs. The policy considers relevance, Choice confidence and Noul output, but does not treat confidence as the probability of correctness. Contradictions are preserved rather than discarded. Borderline or low-relevance cases go to human review.

Labels:

- `SUPPORTING_CANDIDATE`: sufficiently relevant under the provisional rubric to warrant human inspection.
- `COUNTER_EVIDENCE`: model-identified potentially contradictory evidence, retained for review.
- `INVESTIGATE_FURTHER`: evidence may be useful but does not meet the supporting threshold.
- `HUMAN_REVIEW`: insufficient, weakly relevant or low-concentration judgment.

Evidence-triage labels include `NO_AUTOMATIC_ROUTE_CHANGE`. They remain separate from the route-ranking workflow below.

## Jev-weighted pathfinding (direct cost-function control)

The route planner no longer uses Jev only to rank finished paths. Jev produces the objective-weight vector **before** the Python search begins, and the vector is passed into the planner's actual edge-cost scalarization.

1. The user writes a mission-intent prompt (maximum 600 characters) and chooses a provider in JEV INTEL.
2. The TypeScript decision service provides Jev with the prompt, the spatial layers actually available, and the definitions of each route-cost objective.
3. Jev uses `Choice` to choose a strategic focus (`balanced`, `risk_first`, `efficiency_first`, `science_first` or `uncertainty_first`), `Score` to rate the importance of each available objective from 0–3, and `Noul` to estimate how relevant each objective is to the prompt.
4. MARSCOPE derives a normalized weight vector from Jev's Score/Noul judgments and the selected strategic prior. The versioned policy assigns 90% of the vector to Jev's judgments and 10% to the strategy prior. This is a preference-weighting rule, not a probability of route success or safety.
5. The vector is sent to Python in the `/api/routes` request. It replaces the balanced profile's static objective weights. MARSCOPE's user multipliers can fine-tune that vector, after which the active weights are normalized again.
6. The resulting vector changes weighted multi-objective A*'s cumulative path-cost ranking, queue priority, distance heuristic contribution, and bounded per-cell Pareto-label pruning. The LPA* incremental planner receives the same vector, so obstacle and condition repairs preserve the mission preferences.
7. The balanced route is labelled `JEV-ADAPTIVE`. Conservative and science-first routes retain their static profile vectors as comparison baselines; shared manual multipliers can still fine-tune them. The UI shows the model, strategy and applied objective weights.

Only objectives backed by available spatial layers are sent to Jev. Environment risk, radiation and science opportunity cost are omitted when their corresponding data layers are unavailable; unavailable data is not treated as a measured zero. The Jev-generated vector is validated as finite, non-negative and bounded before it reaches Python. The model cannot set coordinates, change terrain values, change the slope/temperature/obstacle tests, or waive time, energy, oxygen and return-reserve feasibility checks. If the Jev request fails or returns malformed judgments, no new Jev-weighted plan is generated and the prior plan remains on screen. Without a Jev key, the normal static-profile A*/LPA* pathfinder continues to work.

The decision service writes a local audit entry containing provider, model, prompt, selected strategy, derived weights and policy version. It never records the API key. Jev's judgments and the derived weights are not empirically calibrated; evaluate route differences against labelled terrain scenarios before making research-performance claims. All mobility/resource values in this prototype remain illustrative assumptions, not operational astronaut guidance.

## Experimental visual annotation

The image workflow fetches only the fixed NASA/JPL PIA26560 JPEG URL. The user cannot supply a URL. It uses TypeSafe's experimental image support, opts in with `TypeSafe-Danger-Zone-Images: true`, and requests a Box answer from `jev-preview`.

The response is a normalized rectangle (`top`, `bottom`, `left`, `right`) in fractions of the source image dimensions. It is not a latitude/longitude, rover pose, map projection, terrain coordinate or geological classification. A human must verify the rectangle. No image box is currently sent to Python's route planner.

## Required evaluation before research claims

Build a human-labelled evaluation set stratified across supporting, contradictory, contextual and insufficient records. Evaluate macro-F1, per-class precision/recall, support precision, false-support rate, Noul Brier score/calibration, human-review frequency, model version, latency and token usage. Compare retrieval-only, retrieval plus deterministic rubric and retrieval plus Jev. Report negative results and disagreements. Recalibrate thresholds on a held-out set before changing the policy version.
