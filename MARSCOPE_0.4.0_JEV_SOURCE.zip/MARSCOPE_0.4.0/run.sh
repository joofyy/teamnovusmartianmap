#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 22.15+ is required for the TypeSafe Jev service." >&2; exit 1
fi
NODE_VERSION="$(node -p 'process.versions.node')"
NODE_MAJOR="${NODE_VERSION%%.*}"
NODE_MINOR="$(node -p 'Number(process.versions.node.split(".")[1])')"
if [[ "$NODE_MAJOR" -lt 22 || ( "$NODE_MAJOR" -eq 22 && "$NODE_MINOR" -lt 15 ) ]]; then
  echo "Node.js 22.15+ is required. Current version: $(node --version)" >&2; exit 1
fi

PYTHON_BIN="${PYTHON:-python3}"
if ! "$PYTHON_BIN" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)'; then
  echo "Python 3.11+ is required. Set PYTHON to its executable if needed." >&2; exit 1
fi
if [[ ! -x .venv/bin/python ]]; then
  "$PYTHON_BIN" -m venv .venv
fi
source .venv/bin/activate
if [[ ! -f .venv/.marscope-python-ready ]]; then
  python -m pip install --disable-pip-version-check -r backend/requirements.txt
  touch .venv/.marscope-python-ready
fi

if [[ ! -x frontend/node_modules/.bin/vite ]]; then
  npm --prefix frontend install --no-audit --no-fund
fi
npm --prefix frontend run build

if [[ ! -f decision-service/node_modules/@typesafe-ai/sdk/package.json ]]; then
  npm --prefix decision-service install --no-audit --no-fund
fi
npm --prefix decision-service run build
npm --prefix decision-service test
exec node decision-service/dist/server.js
