import express, { type NextFunction, type Request, type Response as ExpressResponse } from "express";
import httpProxy from "http-proxy";
import { spawn, type ChildProcess } from "node:child_process";
import { ServerResponse } from "node:http";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { evaluateNasaEvidence, evaluateRouteCandidates, evaluatePathfindingWeights, JEV_EVIDENCE_MODEL, OPENCODE_JEV_MODEL, locateBoxworkInNasaImage, type JevProvider, type NasaEvidenceInput, type RouteCandidateInput } from "./jevDecision.js";

const here = dirname(fileURLToPath(import.meta.url));
const projectRoot = resolve(here, "../..");
const backendDir = resolve(projectRoot, "backend");
const frontendDist = resolve(projectRoot, "frontend", "dist");
const auditPath = resolve(projectRoot, "decision-service", "data", "decision-audit.json");
const routeAuditPath = resolve(projectRoot, "decision-service", "data", "route-decision-audit.json");
const pathfindingWeightAuditPath = resolve(projectRoot, "decision-service", "data", "pathfinding-weight-audit.json");
const pythonPort = Number(process.env.MARSCOPE_PYTHON_PORT || 8001);
const webPort = Number(process.env.MARSCOPE_PORT || 8000);
const pythonBase = `http://127.0.0.1:${pythonPort}`;

if (!existsSync(frontendDist)) {
  console.error("[MARSCOPE] frontend/dist is missing. Run RUN_MARSCOPE.bat so the launcher can build the UI.");
  process.exit(1);
}

const pythonCandidates = process.platform === "win32"
  ? [resolve(projectRoot, ".venv", "Scripts", "python.exe")]
  : [resolve(projectRoot, ".venv", "bin", "python")];
const configuredPython = process.env.MARSCOPE_PYTHON;
const pythonExecutable = configuredPython || pythonCandidates.find((candidate) => existsSync(candidate)) || (process.platform === "win32" ? "python" : "python3");

let pythonProcess: ChildProcess | undefined;
let shuttingDown = false;

function startPython(): ChildProcess {
  console.log(`[MARSCOPE] Starting scientific API with ${pythonExecutable}…`);
  const child = spawn(pythonExecutable, ["-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", String(pythonPort)], {
    cwd: backendDir,
    env: { ...process.env, PYTHONUNBUFFERED: "1" },
    stdio: "inherit",
    windowsHide: true,
  });
  child.on("error", (error) => console.error(`[MARSCOPE] Could not start Python backend: ${error.message}`));
  child.on("exit", (code, signal) => {
    if (!shuttingDown) {
      console.error(`[MARSCOPE] Python backend exited (code=${code}, signal=${signal}).`);
      process.exitCode = 1;
    }
  });
  return child;
}

async function waitForPython(child: ChildProcess): Promise<void> {
  for (let attempt = 0; attempt < 90; attempt += 1) {
    if (child.exitCode !== null) throw new Error("Python backend exited before becoming healthy. Review the Python error above.");
    try {
      const response = await fetch(`${pythonBase}/api/health`, { signal: AbortSignal.timeout(1500) });
      if (response.ok) {
        const health = await response.json() as { release?: string };
        console.log(`[MARSCOPE] Scientific API ready (release ${health.release ?? "unknown"}).`);
        return;
      }
    } catch { /* The backend is still starting. */ }
    await new Promise((resolvePromise) => setTimeout(resolvePromise, 1000));
  }
  throw new Error("Timed out waiting for the Python scientific API on port " + pythonPort + ".");
}

interface EvidenceResponse { records?: NasaEvidenceInput[] }
interface AuditEntry {
  timestamp: string;
  model: string;
  objective: string;
  hypothesis: string;
  evidenceIds: string[];
  decisions: Array<{ evidenceId: string; label: string; stance: string; relevance: number }>;
}

async function readResponseLimited(response: Response, maxBytes: number): Promise<Uint8Array> {
  const reader = response.body?.getReader();
  if (!reader) throw new Error("NASA/JPL image response had no readable body.");
  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > maxBytes) {
        await reader.cancel();
        throw new Error(`NASA/JPL image exceeds the ${Math.round(maxBytes / (1024 * 1024))} MB annotation limit.`);
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const result = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    result.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return result;
}

function appendAudit(entry: AuditEntry): void {
  try {
    mkdirSync(dirname(auditPath), { recursive: true });
    let entries: AuditEntry[] = [];
    if (existsSync(auditPath)) {
      try { entries = JSON.parse(readFileSync(auditPath, "utf8")) as AuditEntry[]; } catch { entries = []; }
    }
    entries.push(entry);
    writeFileSync(auditPath, JSON.stringify(entries.slice(-200), null, 2) + "\n", { encoding: "utf8", mode: 0o600 });
  } catch (error) {
    console.warn(`[MARSCOPE] Decision audit could not be written: ${error instanceof Error ? error.message : "unknown error"}`);
  }
}


interface RouteAuditEntry {
  timestamp: string;
  provider: JevProvider;
  model: string;
  candidateIds: string[];
  selectedRouteId: string;
  scores: Array<{ routeId: string; score: number; missionFitProbability: number; choiceProbability: number; fusionScore: number }>;
  policyVersion: string;
}

function appendRouteAudit(entry: RouteAuditEntry): void {
  try {
    mkdirSync(dirname(routeAuditPath), { recursive: true });
    let entries: RouteAuditEntry[] = [];
    if (existsSync(routeAuditPath)) {
      try { entries = JSON.parse(readFileSync(routeAuditPath, "utf8")) as RouteAuditEntry[]; } catch { entries = []; }
    }
    entries.push(entry);
    writeFileSync(routeAuditPath, JSON.stringify(entries.slice(-200), null, 2) + "\n", { encoding: "utf8", mode: 0o600 });
  } catch (error) {
    console.warn(`[MARSCOPE] Route decision audit could not be written: ${error instanceof Error ? error.message : "unknown error"}`);
  }
}

function requiredText(value: unknown, label: string, maxLength: number): string {
  if (typeof value !== "string" || !value.trim() || value.length > maxLength) {
    throw new Error(`${label} must contain 1–${maxLength} characters.`);
  }
  return value.trim();
}

function requiredMetric(metrics: Record<string, unknown>, key: string): number {
  const value = metrics[key];
  if (typeof value !== "number" || !Number.isFinite(value)) throw new Error(`Candidate route metric ${key} must be a finite number.`);
  return value;
}

function nullableMetric(metrics: Record<string, unknown>, key: string): number | null {
  const value = metrics[key];
  if (value === null || value === undefined) return null;
  if (typeof value !== "number" || !Number.isFinite(value)) throw new Error(`Candidate route metric ${key} must be a number or null.`);
  return value;
}

function parseRouteCandidate(value: unknown): RouteCandidateInput {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Each route candidate must be an object.");
  const candidate = value as Record<string, unknown>;
  const rawMetrics = candidate.metrics;
  if (!rawMetrics || typeof rawMetrics !== "object" || Array.isArray(rawMetrics)) throw new Error("Each route candidate must include route metrics.");
  const metrics = rawMetrics as Record<string, unknown>;
  if (metrics.return_feasible !== true) throw new Error("Jev may rank only routes that pass MARSCOPE's deterministic return-feasibility check.");
  const oxygen = nullableMetric(metrics, "oxygen_l");
  const returnOxygen = nullableMetric(metrics, "return_oxygen_l");
  return {
    id: requiredText(candidate.id, "Candidate ID", 12),
    name: requiredText(candidate.name, "Candidate name", 80),
    profile: requiredText(candidate.profile, "Candidate profile", 40),
    metrics: {
      distance_m: requiredMetric(metrics, "distance_m"),
      duration_min: requiredMetric(metrics, "duration_min"),
      energy_wh: requiredMetric(metrics, "energy_wh"),
      terrain_risk_pct: requiredMetric(metrics, "terrain_risk_pct"),
      environment_risk_pct: nullableMetric(metrics, "environment_risk_pct"),
      radiation_index_pct: nullableMetric(metrics, "radiation_index_pct"),
      uncertainty_pct: requiredMetric(metrics, "uncertainty_pct"),
      scientific_value_pct: nullableMetric(metrics, "scientific_value_pct"),
      return_feasible: true,
      ...(oxygen !== null ? { oxygen_l: oxygen } : {}),
      ...(returnOxygen !== null ? { return_oxygen_l: returnOxygen } : {}),
    },
  };
}

const app = express();
app.disable("x-powered-by");
app.set("trust proxy", false);

// Temporary Jev key endpoint: no request-body logging, no cookie, no disk write.
app.get("/api/decision/status", (_req: Request, res: ExpressResponse) => {
  res.setHeader("Cache-Control", "no-store");
  res.json({
    status: "ready",
    providers: [
      { id: "typesafe", label: "TypeSafe", model: JEV_EVIDENCE_MODEL, imageAnnotation: true },
      { id: "opencode", label: "OpenCode Console", model: OPENCODE_JEV_MODEL, freeTemporarily: true, imageAnnotation: false },
    ],
    keyStorage: "request-memory-only",
    integration: "TypeSafe SDK + OpenCode System One HTTP API",
  });
});

app.post("/api/decision/evaluate", express.json({ limit: "128kb" }), async (req: Request, res: ExpressResponse) => {
  res.setHeader("Cache-Control", "no-store");
  try {
    const apiKey = typeof req.body?.apiKey === "string" ? req.body.apiKey : "";
    const requestedProvider = req.body?.provider ?? "typesafe";
    if (requestedProvider !== "typesafe" && requestedProvider !== "opencode") {
      res.status(400).json({ detail: "Choose TypeSafe or OpenCode as the Jev provider." });
      return;
    }
    const provider = requestedProvider as JevProvider;
    const providerName = provider === "opencode" ? "OpenCode Console" : "TypeSafe";
    const objective = typeof req.body?.objective === "string" ? req.body.objective : "";
    const hypothesis = typeof req.body?.hypothesis === "string" ? req.body.hypothesis : "";
    const evidenceIds: string[] = Array.isArray(req.body?.evidenceIds)
      ? (req.body.evidenceIds as unknown[]).filter((value: unknown): value is string => typeof value === "string")
      : [];
    if (!apiKey.trim() || apiKey.length > 1024) {
      res.status(400).json({ detail: `Enter your ${providerName} API key (maximum 1,024 characters).` });
      return;
    }
    if (!objective.trim() || objective.length > 500 || !hypothesis.trim() || hypothesis.length > 700) {
      res.status(400).json({ detail: "Provide an objective (1–500 characters) and hypothesis (1–700 characters)." });
      return;
    }
    if (evidenceIds.length < 1 || evidenceIds.length > 4) {
      res.status(400).json({ detail: "Choose between 1 and 4 NASA evidence records." });
      return;
    }
    const evidenceResponse = await fetch(`${pythonBase}/api/science/evidence`, { signal: AbortSignal.timeout(12_000) });
    if (!evidenceResponse.ok) throw new Error("Could not retrieve the local NASA evidence catalogue.");
    const catalogue = await evidenceResponse.json() as EvidenceResponse;
    const byId = new Map((catalogue.records ?? []).map((record) => [record.id, record]));
    const selected = evidenceIds.map((id) => byId.get(id)).filter((item): item is NasaEvidenceInput => Boolean(item));
    if (selected.length !== evidenceIds.length) {
      res.status(400).json({ detail: "One or more selected evidence IDs are not present in the curated NASA evidence catalogue." });
      return;
    }
    const result = await evaluateNasaEvidence({ apiKey, provider, objective, hypothesis, evidence: selected });
    appendAudit({
      timestamp: result.evaluatedAt,
      model: result.model,
      objective: objective.slice(0, 500),
      hypothesis: hypothesis.slice(0, 700),
      evidenceIds: selected.map((item) => item.id),
      decisions: result.results.map((item) => ({ evidenceId: item.evidenceId, label: item.decision.label, stance: item.stance, relevance: item.relevanceScore })),
    });
    res.json(result);
  } catch (error) {
    const errorType = error instanceof Error ? error.name : "UnknownError";
    const failedProvider: JevProvider = req.body?.provider === "opencode" ? "opencode" : "typesafe";
    const failedProviderName = failedProvider === "opencode" ? "OpenCode Console" : "TypeSafe";
    // Only surface our own sanitized OpenCode HTTP-status message. Never echo
    // upstream response bodies or arbitrary exception text into the browser.
    const safeOpenCodeStatus = failedProvider === "opencode" && error instanceof Error && /^OpenCode Jev returned HTTP \d+\./.test(error.message)
      ? error.message
      : null;
    const detail = safeOpenCodeStatus ?? `${failedProviderName} Jev evaluation failed (${errorType}). Check the key, network, account access and model availability.`;
    res.status(502).json({ detail, provider: failedProviderName, notice: "No fallback judgment was generated." });
  }
});





app.post("/api/decision/pathfinding-weights", express.json({ limit: "32kb" }), async (req: Request, res: ExpressResponse) => {
  res.setHeader("Cache-Control", "no-store");
  try {
    const apiKey = typeof req.body?.apiKey === "string" ? req.body.apiKey : "";
    const requestedProvider = req.body?.provider ?? "opencode";
    if (requestedProvider !== "typesafe" && requestedProvider !== "opencode") {
      res.status(400).json({ detail: "Choose TypeSafe or OpenCode as the Jev provider." });
      return;
    }
    const provider = requestedProvider as JevProvider;
    const providerName = provider === "opencode" ? "OpenCode Console" : "TypeSafe";
    if (!apiKey.trim() || apiKey.length > 1024) {
      res.status(400).json({ detail: `Enter your ${providerName} API key (maximum 1,024 characters).` });
      return;
    }
    const missionPrompt = requiredText(req.body?.missionPrompt, "Mission prompt", 600);
    const availableLayers = Array.isArray(req.body?.availableLayers)
      ? (req.body.availableLayers as unknown[]).filter((value): value is string => typeof value === "string")
      : [];
    if (!Array.isArray(req.body?.availableLayers) || availableLayers.length !== req.body.availableLayers.length) {
      res.status(400).json({ detail: "Provide the available terrain layer identifiers as a string array." });
      return;
    }
    const rawMissionContext = req.body?.missionContext;
    if (rawMissionContext !== undefined && (!rawMissionContext || typeof rawMissionContext !== "object" || Array.isArray(rawMissionContext))) {
      res.status(400).json({ detail: "Mission context must be a simple object of operational-constraint fields." });
      return;
    }
    const missionContext = (rawMissionContext ?? {}) as Record<string, string | number | boolean | null>;
    const result = await evaluatePathfindingWeights({ apiKey, provider, missionPrompt, availableLayers, missionContext });
    try {
      mkdirSync(dirname(pathfindingWeightAuditPath), { recursive: true });
      let entries: Array<Record<string, unknown>> = [];
      if (existsSync(pathfindingWeightAuditPath)) {
        try { entries = JSON.parse(readFileSync(pathfindingWeightAuditPath, "utf8")) as Array<Record<string, unknown>>; } catch { entries = []; }
      }
      entries.push({
        timestamp: result.evaluatedAt,
        provider: result.provider,
        model: result.model,
        missionPrompt: result.missionPrompt.slice(0, 600),
        strategy: result.strategy,
        weights: result.weights,
        policyVersion: result.policyVersion,
      });
      writeFileSync(pathfindingWeightAuditPath, JSON.stringify(entries.slice(-200), null, 2) + "\n", { encoding: "utf8", mode: 0o600 });
    } catch (auditError) {
      console.warn(`[MARSCOPE] Pathfinding weight audit could not be written: ${auditError instanceof Error ? auditError.message : "unknown error"}`);
    }
    res.json(result);
  } catch (error) {
    const errorType = error instanceof Error ? error.name : "UnknownError";
    const failedProvider: JevProvider = req.body?.provider === "typesafe" ? "typesafe" : "opencode";
    const providerName = failedProvider === "opencode" ? "OpenCode Console" : "TypeSafe";
    const safeOpenCodeStatus = failedProvider === "opencode" && error instanceof Error && /^OpenCode Jev returned HTTP \d+\./.test(error.message)
      ? error.message
      : null;
    const validationError = error instanceof Error && /^(Enter |Mission prompt|Mission context|Available terrain|The terrain|Jev |OpenCode Console|TypeSafe)/.test(error.message)
      ? error.message
      : null;
    const detail = safeOpenCodeStatus ?? validationError ?? `${providerName} Jev pathfinding-weight evaluation failed (${errorType}). Check the key, network, account access and model availability.`;
    res.status(validationError ? 400 : 502).json({ detail, provider: providerName, notice: "No fallback weight vector was applied. The current route plan remains unchanged." });
  }
});

app.post("/api/decision/optimize-route", express.json({ limit: "64kb" }), async (req: Request, res: ExpressResponse) => {
  res.setHeader("Cache-Control", "no-store");
  try {
    const apiKey = typeof req.body?.apiKey === "string" ? req.body.apiKey : "";
    const requestedProvider = req.body?.provider ?? "opencode";
    if (requestedProvider !== "typesafe" && requestedProvider !== "opencode") {
      res.status(400).json({ detail: "Choose TypeSafe or OpenCode as the Jev provider." });
      return;
    }
    const provider = requestedProvider as JevProvider;
    const providerName = provider === "opencode" ? "OpenCode Console" : "TypeSafe";
    if (!apiKey.trim() || apiKey.length > 1024) {
      res.status(400).json({ detail: `Enter your ${providerName} API key (maximum 1,024 characters).` });
      return;
    }
    const missionPrompt = requiredText(req.body?.missionPrompt, "Mission prompt", 600);
    if (!Array.isArray(req.body?.candidates) || req.body.candidates.length < 2 || req.body.candidates.length > 4) {
      res.status(400).json({ detail: "Provide between 2 and 4 route alternatives for Jev to compare." });
      return;
    }
    const candidates = (req.body.candidates as unknown[]).map(parseRouteCandidate);
    const result = await evaluateRouteCandidates({ apiKey, provider, missionPrompt, candidates });
    appendRouteAudit({
      timestamp: result.evaluatedAt,
      provider: result.provider,
      model: result.model,
      candidateIds: candidates.map((candidate) => candidate.id),
      selectedRouteId: result.selectedRouteId,
      scores: result.results.map((item) => ({
        routeId: item.routeId,
        score: item.score,
        missionFitProbability: item.missionFitProbability,
        choiceProbability: item.choiceProbability,
        fusionScore: item.fusionScore,
      })),
      policyVersion: result.policyVersion,
    });
    res.json(result);
  } catch (error) {
    const errorType = error instanceof Error ? error.name : "UnknownError";
    const failedProvider: JevProvider = req.body?.provider === "typesafe" ? "typesafe" : "opencode";
    const providerName = failedProvider === "opencode" ? "OpenCode Console" : "TypeSafe";
    const safeOpenCodeStatus = failedProvider === "opencode" && error instanceof Error && /^OpenCode Jev returned HTTP \d+\./.test(error.message)
      ? error.message
      : null;
    const validationError = error instanceof Error && /^(Enter |Mission prompt|Candidate |Each route|Jev may|Only routes|Route candidate|Jev route ranking|Jev route evaluation)/.test(error.message)
      ? error.message
      : null;
    const detail = safeOpenCodeStatus ?? validationError ?? `${providerName} route evaluation failed (${errorType}). Check the key, network, account access and model availability.`;
    res.status(validationError ? 400 : 502).json({ detail, provider: providerName, notice: "No alternate route was selected. Existing deterministic route options remain unchanged." });
  }
});

app.post("/api/decision/annotate-nasa-image", express.json({ limit: "128kb" }), async (req: Request, res: ExpressResponse) => {
  res.setHeader("Cache-Control", "no-store");
  try {
    const apiKey = typeof req.body?.apiKey === "string" ? req.body.apiKey : "";
    if (!apiKey.trim() || apiKey.length > 1024) {
      res.status(400).json({ detail: "Enter your TypeSafe API key (maximum 1,024 characters)." });
      return;
    }
    // Fixed source URL: clients cannot supply arbitrary URLs or turn this into an SSRF proxy.
    const imageUrl = "https://d2pn8kiwq2w21t.cloudfront.net/original_images/jpegPIA26560.jpg";
    const imageResponse = await fetch(imageUrl, { signal: AbortSignal.timeout(25_000), redirect: "error" });
    if (!imageResponse.ok || !imageResponse.headers.get("content-type")?.toLowerCase().includes("image/jpeg")) {
      throw new Error("NASA/JPL PIA26560 panorama could not be retrieved as a JPEG image.");
    }
    const declaredSize = Number(imageResponse.headers.get("content-length") || 0);
    if (declaredSize > 20 * 1024 * 1024) throw new Error("NASA/JPL image exceeds the 20 MB annotation limit.");
    const imageBytes = await readResponseLimited(imageResponse, 20 * 1024 * 1024);
    const result = await locateBoxworkInNasaImage({ apiKey, imageBytes });
    res.json(result);
  } catch (error) {
    const errorType = error instanceof Error ? error.name : "UnknownError";
    res.status(502).json({ detail: `NASA image / Jev annotation failed (${errorType}). Check network access, the API key and preview-model availability.`, provider: "TypeSafe Jev preview", notice: "Image support is experimental. No Mars coordinates or navigation update were produced." });
  }
});

const proxy = httpProxy.createProxyServer({ target: pythonBase, changeOrigin: true, xfwd: false });
proxy.on("error", (error, _req, res) => {
  console.error(`[MARSCOPE] Scientific API proxy error: ${error.message}`);
  if (res instanceof ServerResponse && !res.headersSent) {
    res.writeHead(502, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" });
    res.end(JSON.stringify({ detail: "The scientific backend is unavailable. Restart MARSCOPE and try again." }));
  }
});
// Do not mount on "/api": Express strips the mount prefix before forwarding.
// Preserve the complete /api path for FastAPI (and forward /docs for local API help).
app.use((req: Request, res: ExpressResponse, next: NextFunction) => {
  const path = req.path;
  if (path.startsWith("/api/") || path === "/docs" || path.startsWith("/docs/") || path === "/openapi.json" || path === "/redoc") {
    proxy.web(req, res);
    return;
  }
  next();
});

app.use(express.static(frontendDist, { etag: true, maxAge: "1h" }));
app.get("*", (_req, res) => res.sendFile(resolve(frontendDist, "index.html")));

async function main(): Promise<void> {
  pythonProcess = startPython();
  await waitForPython(pythonProcess);
  const server = app.listen(webPort, "127.0.0.1", () => {
    const url = `http://127.0.0.1:${webPort}`;
    console.log("\n  MARSCOPE 0.4.0 is running");
    console.log(`  Mission interface: ${url}`);
    console.log(`  API documentation: ${url}/docs`);
    console.log("  Jev key policy: entered per evaluation; never saved by MARSCOPE.\n");
    if (process.env.MARSCOPE_NO_BROWSER !== "1") {
      const command = process.platform === "win32" ? "cmd" : process.platform === "darwin" ? "open" : "xdg-open";
      const args = process.platform === "win32" ? ["/c", "start", "", url] : [url];
      const opener = spawn(command, args, { stdio: "ignore", detached: true, windowsHide: true });
      opener.unref();
    }
  });
  const stop = () => {
    if (shuttingDown) return;
    shuttingDown = true;
    console.log("\n[MARSCOPE] Shutting down services…");
    server.close();
    proxy.close();
    pythonProcess?.kill();
    setTimeout(() => process.exit(0), 300).unref();
  };
  process.on("SIGINT", stop);
  process.on("SIGTERM", stop);
}

main().catch((error) => {
  console.error(`[MARSCOPE] Startup failed: ${error instanceof Error ? error.message : "unknown error"}`);
  shuttingDown = true;
  pythonProcess?.kill();
  process.exit(1);
});
