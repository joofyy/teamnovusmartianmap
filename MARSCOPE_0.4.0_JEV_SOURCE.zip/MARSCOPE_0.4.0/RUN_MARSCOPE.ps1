$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $ProjectRoot

$LogDirectory = Join-Path $ProjectRoot '.run-logs'
New-Item -ItemType Directory -Path $LogDirectory -Force | Out-Null
$LogPath = Join-Path $LogDirectory 'marscope-startup.log'
$TranscriptStarted = $false

function Write-Step {
    param([string]$Message)
    Write-Host "`n>>> $Message" -ForegroundColor Cyan
}

function Invoke-Checked {
    param(
        [Parameter(Mandatory = $true)][string]$Executable,
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [Parameter(Mandatory = $true)][string]$WorkingDirectory,
        [Parameter(Mandatory = $true)][string]$Description
    )

    Push-Location -LiteralPath $WorkingDirectory
    try {
        & $Executable @Arguments
        $ExitCode = $LASTEXITCODE
    }
    finally {
        Pop-Location
    }

    if ($null -eq $ExitCode -or $ExitCode -ne 0) {
        throw "$Description failed with exit code $ExitCode. See $LogPath"
    }
}

function Get-FreeBytesForPath {
    param([Parameter(Mandatory = $true)][string]$Path)

    $Root = [System.IO.Path]::GetPathRoot([System.IO.Path]::GetFullPath($Path))
    if ([string]::IsNullOrWhiteSpace($Root)) { return [long]::MaxValue }
    $DriveName = $Root.Substring(0, 1)
    $Drive = Get-PSDrive -Name $DriveName -ErrorAction SilentlyContinue
    if ($null -eq $Drive -or $null -eq $Drive.Free) { return [long]::MaxValue }
    return [long]$Drive.Free
}

function Assert-InstallSpace {
    param([Parameter(Mandatory = $true)][string]$Path, [Parameter(Mandatory = $true)][string]$Label)

    # Keep a 1 GiB buffer for unpacked packages, npm cache, and the production build.
    $FreeBytes = Get-FreeBytesForPath -Path $Path
    $RequiredBytes = 1GB
    if ($FreeBytes -lt $RequiredBytes) {
        $FreeGB = [math]::Round($FreeBytes / 1GB, 2)
        throw "$Label has only $FreeGB GB free. Free at least 1 GB before installing npm packages, then run RUN_MARSCOPE.bat again. No dependencies were installed."
    }
}

function Install-NpmDependencies {
    param(
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [Parameter(Mandatory = $true)][string]$WorkingDirectory,
        [Parameter(Mandatory = $true)][string]$NodeModulesPath,
        [Parameter(Mandatory = $true)][string]$Description
    )

    Assert-InstallSpace -Path $ProjectRoot -Label 'The project drive'
    try {
        Invoke-Checked -Executable $NpmCmd -Arguments $Arguments -WorkingDirectory $WorkingDirectory -Description $Description
    }
    catch {
        # npm can leave a partially extracted node_modules after ENOSPC. Remove
        # that incomplete tree so the next launcher run cannot mistake it for a
        # usable install and so it returns some of the consumed disk space.
        if (Test-Path -LiteralPath $NodeModulesPath) {
            try { Remove-Item -LiteralPath $NodeModulesPath -Recurse -Force -ErrorAction Stop }
            catch { Write-Warning "Could not remove the incomplete dependency folder '$NodeModulesPath': $($_.Exception.Message)" }
        }
        throw "$Description failed. Any incomplete node_modules folder was cleaned up where possible. Check free disk space and rerun RUN_MARSCOPE.bat. Details: $($_.Exception.Message)"
    }
}

try {
    try {
        Start-Transcript -Path $LogPath -Append | Out-Null
        $TranscriptStarted = $true
    }
    catch {
        Write-Warning "Could not start transcript logging: $($_.Exception.Message)"
    }

    Write-Host ''
    Write-Host ' MARSCOPE 0.4.0 - POWERSHELL LAUNCHER' -ForegroundColor Magenta
    Write-Host ' ====================================' -ForegroundColor Magenta
    Write-Host " Project: $ProjectRoot"
    Write-Host " Log:     $LogPath"

    # Node.js requirement: >=22.15.0
    Write-Step 'Checking Node.js'
    $NodeCommand = Get-Command 'node.exe' -ErrorAction SilentlyContinue
    if (-not $NodeCommand) { $NodeCommand = Get-Command 'node' -ErrorAction Stop }
    $NodeExe = $NodeCommand.Source
    $NodeVersionText = (& $NodeExe --version).Trim().TrimStart('v')
    $NodeParts = $NodeVersionText.Split('.')
    if ($NodeParts.Count -lt 2) { throw "Could not parse Node.js version: $NodeVersionText" }
    $NodeMajor = [int]$NodeParts[0]
    $NodeMinor = [int]$NodeParts[1]
    if (($NodeMajor -lt 22) -or (($NodeMajor -eq 22) -and ($NodeMinor -lt 15))) {
        throw "Node.js 22.15 or newer is required. Found $NodeVersionText."
    }
    Write-Host "Node.js $NodeVersionText found at $NodeExe" -ForegroundColor Green

    $NpmCommand = Get-Command 'npm.cmd' -ErrorAction SilentlyContinue
    if (-not $NpmCommand) { throw 'npm.cmd was not found. Reinstall Node.js with npm included, then reopen PowerShell.' }
    $NpmCmd = $NpmCommand.Source
    Write-Host "npm found at $NpmCmd" -ForegroundColor Green

    # Python requirement: >=3.11. Prefer the python command already on PATH.
    Write-Step 'Checking Python'
    $PythonCommand = Get-Command 'python.exe' -ErrorAction SilentlyContinue
    if (-not $PythonCommand) { $PythonCommand = Get-Command 'python' -ErrorAction Stop }
    $PythonExe = $PythonCommand.Source
    # Read the interpreter version from its standard --version output.
    # Avoid `python -c` here: Windows PowerShell 5.1 can strip nested quotes
    # when passing inline code to native executables, corrupting the script.
    $PythonVersionOutput = & $PythonExe --version 2>&1
    $PythonVersionExitCode = $LASTEXITCODE
    $PythonVersionText = ($PythonVersionOutput | Out-String).Trim()
    if ($PythonVersionExitCode -ne 0) {
        throw "Python could not run --version (exit code $PythonVersionExitCode): $PythonVersionText"
    }
    if ($PythonVersionText -notmatch '^Python\s+(\d+)\.(\d+)(?:\.(\d+))?') {
        throw "Could not parse Python version output: $PythonVersionText"
    }
    $PythonMajor = [int]$Matches[1]
    $PythonMinor = [int]$Matches[2]
    if (($PythonMajor -lt 3) -or (($PythonMajor -eq 3) -and ($PythonMinor -lt 11))) {
        throw "Python 3.11 or newer is required. Found $PythonVersionText at $PythonExe."
    }
    Write-Host "$PythonVersionText found at $PythonExe" -ForegroundColor Green

    # Verify the actual interpreter and compiled extension imports. A previous
    # interrupted install can leave valid package metadata alongside a broken
    # .pyd binary; pip then reports 'Requirement already satisfied'. In that
    # case, recreate the entire venv rather than trying to repair it in place.
    Write-Step 'Checking / installing Python packages'
    $VenvDirectory = Join-Path $ProjectRoot '.venv'
    $VenvPython = Join-Path $VenvDirectory 'Scripts\python.exe'
    $PythonEnvironmentHealthy = $false

    if (Test-Path -LiteralPath $VenvPython) {
        Write-Host 'Checking existing Python virtual environment...' -ForegroundColor DarkGray
        & $VenvPython -c 'import fastapi, uvicorn, numpy, pydantic, pydantic_core; import pydantic_core._pydantic_core'
        $PythonImportExitCode = $LASTEXITCODE
        if ($PythonImportExitCode -eq 0) {
            $PythonEnvironmentHealthy = $true
            Write-Host 'Python packages and compiled extensions are healthy.' -ForegroundColor Green
        }
        else {
            Write-Warning 'The existing .venv has missing or damaged packages. It will be rebuilt from scratch.'
        }
    }

    if (-not $PythonEnvironmentHealthy) {
        if (Test-Path -LiteralPath $VenvDirectory) {
            try {
                Remove-Item -LiteralPath $VenvDirectory -Recurse -Force -ErrorAction Stop
            }
            catch {
                throw "Could not remove the damaged .venv at '$VenvDirectory'. Close Python processes using this project, delete the .venv folder, and run RUN_MARSCOPE.bat again. Details: $($_.Exception.Message)"
            }
        }

        Write-Step 'Creating a clean Python virtual environment'
        & $PythonExe -m venv $VenvDirectory
        if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $VenvPython)) {
            throw 'Could not create .venv. Check that your Python installation includes the venv module.'
        }

        Write-Step 'Installing Python packages without using cached wheels'
        Invoke-Checked -Executable $VenvPython -Arguments @('-m', 'pip', 'install', '--disable-pip-version-check', '--no-cache-dir', '-r', 'requirements.txt') -WorkingDirectory (Join-Path $ProjectRoot 'backend') -Description 'Python dependency installation'

        Write-Step 'Verifying Python packages and compiled extensions'
        & $VenvPython -c 'import fastapi, uvicorn, numpy, pydantic, pydantic_core; import pydantic_core._pydantic_core'
        if ($LASTEXITCODE -ne 0) {
            throw 'Python dependencies were installed but an import or compiled-extension check failed. Delete .venv, check that Python is 64-bit, and rerun RUN_MARSCOPE.bat.'
        }
        Write-Host 'Python dependencies verified successfully.' -ForegroundColor Green
    }

    # Validate all direct frontend dependencies. Checking only vite.cmd can
    # incorrectly accept a partial npm install left behind after ENOSPC.
    Write-Step 'Checking / installing frontend packages'
    $FrontendDirectory = Join-Path $ProjectRoot 'frontend'
    $FrontendNodeModules = Join-Path $FrontendDirectory 'node_modules'
    $FrontendDependencyMarkers = @(
        (Join-Path $FrontendNodeModules '.bin\vite.cmd'),
        (Join-Path $FrontendNodeModules 'vite\package.json'),
        (Join-Path $FrontendNodeModules 'typescript\package.json'),
        (Join-Path $FrontendNodeModules '@vitejs\plugin-react\package.json'),
        (Join-Path $FrontendNodeModules 'react\package.json'),
        (Join-Path $FrontendNodeModules 'react-dom\package.json'),
        (Join-Path $FrontendNodeModules 'three\package.json'),
        (Join-Path $FrontendNodeModules '@types\react\package.json'),
        (Join-Path $FrontendNodeModules '@types\react-dom\package.json'),
        (Join-Path $FrontendNodeModules '@types\three\package.json')
    )
    $FrontendReady = $true
    foreach ($Marker in $FrontendDependencyMarkers) {
        if (-not (Test-Path -LiteralPath $Marker)) { $FrontendReady = $false; break }
    }
    if (-not $FrontendReady) {
        if (Test-Path -LiteralPath $FrontendNodeModules) {
            Write-Host 'Removing an incomplete frontend node_modules folder before reinstalling.' -ForegroundColor Yellow
            Remove-Item -LiteralPath $FrontendNodeModules -Recurse -Force
        }
        Install-NpmDependencies -Arguments @('install', '--no-audit', '--no-fund') -WorkingDirectory $FrontendDirectory -NodeModulesPath $FrontendNodeModules -Description 'Frontend package installation'
    }
    else {
        Write-Host 'Frontend dependencies already installed and validated.' -ForegroundColor Green
    }

    Write-Step 'Building React / TypeScript frontend'
    Invoke-Checked -Executable $NpmCmd -Arguments @('run', 'build') -WorkingDirectory (Join-Path $ProjectRoot 'frontend') -Description 'Frontend build'

    # Validate runtime and type packages used by the decision service.
    Write-Step 'Checking / installing Jev provider packages'
    $DecisionDirectory = Join-Path $ProjectRoot 'decision-service'
    $DecisionNodeModules = Join-Path $DecisionDirectory 'node_modules'
    $DecisionDependencyMarkers = @(
        (Join-Path $DecisionNodeModules '.bin\tsc.cmd'),
        (Join-Path $DecisionNodeModules '@typesafe-ai\sdk\package.json'),
        (Join-Path $DecisionNodeModules 'express\package.json'),
        (Join-Path $DecisionNodeModules 'http-proxy\package.json'),
        (Join-Path $DecisionNodeModules 'typescript\package.json'),
        (Join-Path $DecisionNodeModules '@types\express\package.json'),
        (Join-Path $DecisionNodeModules '@types\http-proxy\package.json'),
        (Join-Path $DecisionNodeModules '@types\node\package.json')
    )
    $DecisionReady = $true
    foreach ($Marker in $DecisionDependencyMarkers) {
        if (-not (Test-Path -LiteralPath $Marker)) { $DecisionReady = $false; break }
    }
    if (-not $DecisionReady) {
        if (Test-Path -LiteralPath $DecisionNodeModules) {
            Write-Host 'Removing an incomplete decision-service node_modules folder before reinstalling.' -ForegroundColor Yellow
            Remove-Item -LiteralPath $DecisionNodeModules -Recurse -Force
        }
        Install-NpmDependencies -Arguments @('install', '--no-audit', '--no-fund') -WorkingDirectory $DecisionDirectory -NodeModulesPath $DecisionNodeModules -Description 'Decision-service package installation'
    }
    else {
        Write-Host 'Decision-service dependencies already installed and validated.' -ForegroundColor Green
    }

    Write-Step 'Building and testing TypeScript decision service'
    $DecisionDirectory = Join-Path $ProjectRoot 'decision-service'
    Invoke-Checked -Executable $NpmCmd -Arguments @('run', 'build') -WorkingDirectory $DecisionDirectory -Description 'TypeScript decision-service build'
    Invoke-Checked -Executable $NpmCmd -Arguments @('test') -WorkingDirectory $DecisionDirectory -Description 'TypeScript decision-service tests'

    Write-Host ''
    Write-Host ' MARSCOPE is starting.' -ForegroundColor Green
    Write-Host ' App: http://127.0.0.1:8000'
    Write-Host ' API docs: http://127.0.0.1:8000/docs'
    Write-Host ' Keep this window open. Press Ctrl+C to stop.'
    Write-Host ''

    & $NodeExe (Join-Path $ProjectRoot 'decision-service\dist\server.js')
    $ServerExitCode = $LASTEXITCODE
    if ($null -ne $ServerExitCode -and $ServerExitCode -ne 0) {
        throw "MARSCOPE server exited with code $ServerExitCode. See $LogPath"
    }
}
catch {
    Write-Host ''
    Write-Host 'MARSCOPE STARTUP FAILED' -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host "`nFull startup log: $LogPath" -ForegroundColor Yellow
    Write-Host 'Copy the final 60 lines of this log when asking for help.' -ForegroundColor Yellow
    exit 1
}
finally {
    if ($TranscriptStarted) {
        try { Stop-Transcript | Out-Null } catch { }
    }
}
