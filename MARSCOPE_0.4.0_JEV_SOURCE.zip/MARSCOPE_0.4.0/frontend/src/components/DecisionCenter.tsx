import { useEffect, useState } from 'react';
import { api } from '../api';
import type { JevEvaluationResponse, JevImageBoxResponse, NasaEvidenceRecord } from '../types';

const DEFAULT_OBJECTIVE = 'Investigate the geological history of ancient groundwater in the Mount Sharp boxwork region.';
const DEFAULT_HYPOTHESIS = 'Minerals associated with ancient groundwater may have cemented fractures in bedrock, leaving resistant boxwork ridges after later wind erosion.';
const LABELS: Record<string, string> = {
  SUPPORTING_CANDIDATE: 'SUPPORTING CANDIDATE',
  COUNTER_EVIDENCE: 'COUNTER-EVIDENCE',
  INVESTIGATE_FURTHER: 'INVESTIGATE FURTHER',
  HUMAN_REVIEW: 'HUMAN REVIEW',
};

function pct(value: number) { return `${Math.round(Math.min(1, Math.max(0, value)) * 100)}%`; }
function scoreText(value: number) { return `${value.toFixed(2)} / 3`; }

type DecisionCenterProps = {
  apiKey: string;
  onApiKeyChange: (value: string) => void;
  provider: 'typesafe' | 'opencode';
  onProviderChange: (provider: 'typesafe' | 'opencode') => void;
};

export default function DecisionCenter({ apiKey, onApiKeyChange, provider, onProviderChange }: DecisionCenterProps) {
  const [evidence, setEvidence] = useState<NasaEvidenceRecord[]>([]);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [objective, setObjective] = useState(DEFAULT_OBJECTIVE);
  const [hypothesis, setHypothesis] = useState(DEFAULT_HYPOTHESIS);
  const [showKey, setShowKey] = useState(false);
  const [result, setResult] = useState<JevEvaluationResponse | null>(null);
  const [imageResult, setImageResult] = useState<JevImageBoxResponse | null>(null);
  const [annotatingImage, setAnnotatingImage] = useState(false);
  const [loadingEvidence, setLoadingEvidence] = useState(true);
  const [evaluating, setEvaluating] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    let alive = true;
    Promise.all([api.scienceEvidence(), api.jevStatus()])
      .then(([catalogue]) => {
        if (!alive) return;
        setEvidence(catalogue.records);
        const preferred = catalogue.records.slice(0, Math.min(3, catalogue.records.length)).map((record) => record.id);
        setSelectedIds(preferred);
      })
      .catch((err: Error) => { if (alive) setError(err.message) })
      .finally(() => alive && setLoadingEvidence(false));
    return () => { alive = false; };
  }, []);

  const canEvaluate = apiKey.trim().length > 0 && objective.trim().length > 0 && hypothesis.trim().length > 0 && selectedIds.length > 0 && selectedIds.length <= 4;

  const toggleEvidence = (id: string) => {
    setSelectedIds((current) => current.includes(id) ? current.filter((value) => value !== id) : current.length < 4 ? [...current, id] : current);
    setResult(null);
  };

  const annotateNASAImage = async () => {
    if (!apiKey.trim()) return;
    setAnnotatingImage(true); setError(''); setImageResult(null);
    try {
      const response = await api.annotateNasaImage(apiKey.trim());
      setImageResult(response);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Jev image annotation failed.');
    } finally { setAnnotatingImage(false); }
  };

  const evaluate = async () => {
    if (!canEvaluate) return;
    setEvaluating(true); setError(''); setResult(null);
    try {
      const response = await api.evaluateJev({ apiKey: apiKey.trim(), provider, objective, hypothesis, evidenceIds: selectedIds });
      setResult(response);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Jev evaluation failed.');
    } finally { setEvaluating(false); }
  };

  const providerName = provider === 'opencode' ? 'OpenCode Console' : 'TypeSafe';
  const modelLabel = provider === 'opencode' ? 'JEV 1.13 FREE VIA OPENCODE' : 'TYPE SAFE JEV 1.14.0';

  return <div className="decision-center">
    <header className="decision-hero">
      <div className="decision-kicker"><span className="live-source-dot"/> {modelLabel} · SERVER-SIDE EVALUATION</div>
      <h3>Evidence → Decision</h3>
      <p>Evaluate real NASA/JPL source records against a scientific question. Jev returns structured judgments; MARSCOPE applies a transparent review policy.</p>
      <div className="decision-flow"><span>NASA evidence</span><i>→</i><span>Jev judgments</span><i>→</i><span>Review policy</span></div>
    </header>

    <section className="jev-key-card">
      <div className="decision-section-heading"><div><span className="eyebrow">PROVIDER</span><h4>Choose Jev access</h4></div><span className="memory-only-pill">MEMORY ONLY</span></div>
      <label className="jev-provider-label">API PROVIDER
        <select className="jev-provider-select" value={provider} onChange={(event) => {
          const nextProvider = event.target.value as 'typesafe' | 'opencode';
          onProviderChange(nextProvider);
          onApiKeyChange('');
          setResult(null);
          setImageResult(null);
          setError('');
        }}>
          <option value="typesafe">TypeSafe · Jev 1.14.0</option>
          <option value="opencode">OpenCode Console · Jev 1.13 Free (temporary)</option>
        </select>
      </label>
      <div className="decision-section-heading jev-credential-heading"><div><span className="eyebrow">TEMPORARY CREDENTIAL</span><h4>{providerName} API key</h4></div></div>
      <div className="jev-key-row">
        <input type={showKey ? 'text' : 'password'} value={apiKey} onChange={(event) => onApiKeyChange(event.target.value)} autoComplete="new-password" maxLength={1024} spellCheck={false} placeholder={provider === 'opencode' ? 'Paste your OpenCode Console key (oc_sk_...)' : 'Paste your TypeSafe API key'} aria-label={`Temporary ${providerName} API key`} />
        <button type="button" className="key-visibility" onClick={() => setShowKey((value) => !value)}>{showKey ? 'HIDE' : 'SHOW'}</button>
        <button type="button" className="key-clear" onClick={() => { onApiKeyChange(''); setResult(null); setImageResult(null); }}>FORGET</button>
      </div>
      {provider === 'opencode' ? <p className="key-privacy-note"><b>Not saved.</b> Paste an OpenCode Console personal API key. MARSCOPE sends it to the local server, which calls OpenCode over HTTPS using <code>jev-1.13-free</code>. OpenCode currently lists this model as temporarily free; availability can change. The key is not written to browser storage, .env, audit logs or project files. Switching providers clears the key.</p> : <p className="key-privacy-note"><b>Not saved.</b> The key stays in this page's memory, is sent only to the local MARSCOPE server for this evaluation, and is passed to TypeSafe over HTTPS. It is not written to localStorage, .env, audit logs or project files. Refreshing the page clears it. API usage may count against your TypeSafe account. Switching providers clears the key.</p>}
    </section>

    <section className="decision-form-card">
      <div className="decision-section-heading"><div><span className="eyebrow">SCIENTIFIC QUESTION</span><h4>Define the investigation</h4></div><span className="record-count">{selectedIds.length}/4 RECORDS</span></div>
      <label className="decision-label">Mission objective<textarea value={objective} onChange={(event) => setObjective(event.target.value)} maxLength={500} rows={2}/></label>
      <label className="decision-label">Working hypothesis<textarea value={hypothesis} onChange={(event) => setHypothesis(event.target.value)} maxLength={700} rows={3}/></label>
    </section>

    <section className="decision-evidence-list">
      <div className="decision-section-heading"><div><span className="eyebrow">CURATED NASA/JPL RECORDS</span><h4>Select evidence</h4></div><span className="record-count">{loadingEvidence ? 'LOADING…' : `${evidence.length} SOURCES`}</span></div>
      {loadingEvidence && <div className="decision-empty">Retrieving the local source catalogue…</div>}
      {!loadingEvidence && evidence.map((item) => (
        <label className={`decision-evidence-option ${selectedIds.includes(item.id) ? 'selected' : ''}`} key={item.id}>
          <input type="checkbox" checked={selectedIds.includes(item.id)} onChange={() => toggleEvidence(item.id)} disabled={!selectedIds.includes(item.id) && selectedIds.length >= 4}/>
          <span className="decision-evidence-copy"><b>{item.title}</b><small>{item.mission ?? 'NASA archive'} · {item.instrument ?? 'Instrument not specified'} · {item.date}</small>{item.image_url && <img className="decision-evidence-image" src={item.image_url} alt={`${item.title}, original NASA/JPL image`} loading="lazy" referrerPolicy="no-referrer"/>}<span>{item.summary}</span><small className="decision-source-link">{item.id} · <a href={item.url} target="_blank" rel="noreferrer" onClick={(event) => event.stopPropagation()}>ORIGINAL SOURCE ↗</a></small></span>
        </label>
      ))}
      {!loadingEvidence && evidence.length === 0 && <div className="decision-empty">No curated evidence records are available. Check the scientific API and reload.</div>}
    </section>

    <section className="jev-visual-card">
      <div className="decision-section-heading"><div><span className="eyebrow">EXPERIMENTAL · TYPE SAFE PREVIEW MODEL</span><h4>Visual reconnaissance: boxwork candidate</h4></div><span className="record-count">PIA26560</span></div>
      <p className="jev-visual-intro">Use TypeSafe's experimental image Box primitive on the original NASA/JPL Mastcam panorama. It returns a rectangle in image-relative fractions only, never a Mars coordinate. OpenCode's temporary Jev Free integration is enabled for text-based evidence evaluation; this separate preview feature still requires TypeSafe.</p>
      <button type="button" className="jev-secondary-button" disabled={!apiKey.trim() || provider !== 'typesafe' || annotatingImage} onClick={() => void annotateNASAImage()}>
        {provider === 'opencode' ? 'USE TYPESAFE FOR IMAGE ANNOTATION' : annotatingImage ? 'ANALYSING NASA IMAGE…' : 'ANNOTATE NASA PANORAMA WITH JEV'} <span>↗</span>
      </button>
      {imageResult && <div className="jev-image-result">
        <div className="jev-image-frame">
          <img src={imageResult.source.imageUrl} alt="NASA/JPL Curiosity Mastcam panorama, PIA26560" loading="lazy" />
          <div className="jev-image-box" style={{ top: `${imageResult.box.top * 100}%`, left: `${imageResult.box.left * 100}%`, width: `${(imageResult.box.right - imageResult.box.left) * 100}%`, height: `${(imageResult.box.bottom - imageResult.box.top) * 100}%` }}><span>JEV CANDIDATE REGION</span></div>
        </div>
        <div className="jev-visual-meta"><b>{imageResult.model}</b><span>{imageResult.confidence === null ? 'Confidence not reported' : `Jev confidence ${pct(imageResult.confidence)}`}</span><span>{imageResult.source.imageBytes.toLocaleString()} image bytes</span></div>
        <p>{imageResult.notice}</p>
        <a href={imageResult.source.url} target="_blank" rel="noreferrer">OPEN ORIGINAL NASA/JPL RECORD ↗</a>
      </div>}
    </section>

    <button type="button" className="jev-evaluate-button" disabled={!canEvaluate || evaluating || loadingEvidence} onClick={() => void evaluate()}>
      {evaluating ? 'EVALUATING EVIDENCE WITH JEV…' : 'RUN JEV EVIDENCE EVALUATION'} <span>↗</span>
    </button>
    <p className="jev-cost-note">One Jev System One request is made per selected source (maximum four). {provider === 'opencode' ? 'OpenCode currently lists Jev 1.13 Free as temporary free access; check its model page for current availability.' : 'Check your TypeSafe account usage.'} The experimental image annotation is a separate TypeSafe-only request.</p>
    {error && <div className="error-banner">{error}</div>}

    {result && <section className="jev-results">
      <div className="decision-results-head"><div><span className="eyebrow">DECISION TRACE</span><h4>Evidence assessment</h4></div><span className="jev-model-tag">{result.model}</span></div>
      <div className="jev-run-meta">Evaluated {new Date(result.evaluatedAt).toLocaleString()} · {result.results.length} source(s)</div>
      {result.results.map((item) => (
        <article className="jev-result-card" key={item.evidenceId}>
          <div className="jev-result-title"><div><span className="eyebrow">{item.evidenceId}</span><h5>{item.title}</h5></div><span className={`decision-label-chip ${item.decision.label.toLowerCase()}`}>{LABELS[item.decision.label] ?? item.decision.label}</span></div>
          <div className="jev-stance-row"><span>Relationship to hypothesis</span><b>{item.stance.replace(/_/g, ' ').toUpperCase()}</b><small>choice confidence {pct(item.stanceConfidence)}</small></div>
          <div className="jev-score-grid">
            <div><span>RELEVANCE</span><b>{scoreText(item.relevanceScore)}</b><small>Jev confidence {pct(item.relevanceConfidence)}</small></div>
            <div><span>DIRECT SUPPORT</span><b>{pct(item.directSupportProbability)}</b><small>Noul yes probability</small></div>
            <div><span>NOVELTY POTENTIAL</span><b>{scoreText(item.noveltyScore)}</b><small>Jev confidence {pct(item.noveltyConfidence)}</small></div>
          </div>
          <div className="jev-policy-explanation"><b>WHY THIS LABEL</b><p>{item.decision.rationale}</p></div>
          <div className="jev-route-guard"><span>GEOSPATIAL LINK</span><b>{item.decision.geospatialLinkage.replace(/_/g, ' ')}</b><span>ROUTE ENGINE</span><b>NO AUTOMATIC CHANGE</b></div>
          <a className="jev-source-open" href={item.source.url} target="_blank" rel="noreferrer">INSPECT ORIGINAL NASA/JPL SOURCE ↗</a>
        </article>
      ))}
      <div className="jev-global-notice">{result.notice}</div>
      <div className="jev-global-notice">Audit record stores the objective, hypothesis, evidence IDs and resulting labels locally. The API key is excluded.</div>
    </section>}

    <footer className="decision-footnote">Decision support only. Jev's confidence is not a probability that its answer is correct. A score or Noul answer is not a scientific posterior, measured information gain, geological classification or astronaut safety decision. Product labels, instrument documentation and qualified scientific review remain authoritative.</footer>
  </div>;
}
